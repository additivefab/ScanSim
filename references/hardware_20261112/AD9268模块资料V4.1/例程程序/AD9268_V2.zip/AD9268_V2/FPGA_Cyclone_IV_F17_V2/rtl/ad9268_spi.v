module ad9268_spi(
    input   wire  sys_clk  ,
    input   wire  sys_rst  ,
    input   wire  sign_sel ,
    output  wire  spi_cs_n ,
    output  wire  spi_sclk ,
    output  wire  spi_mosi 
);

localparam  delay_100ms  = ( 50_000_000 / 10 ) - 1 ;
localparam  slck_counter = ( 24 * 2 ) - 1 ;

localparam  TRANSFER      = 8'hFF;
localparam  OUTPUT_MODE   = 8'h14;
localparam  DITHER_ENABLE = 8'h30;
localparam  DCO_OUTPUT    = 8'h17;

reg          cs_n ;
reg          sclk ;
reg          mosi ;

wire         cs_nege   ;
wire         sclk_nege ;

reg  [2:0]   spi_state ;
reg          sclk_reg  ;
reg          cs_reg    ;
reg  [23:0]  spi_data  ;
reg  [23:0]  send_data ;
reg  [1:0]   dat_state ;

reg  [23:0]  delay_cnt ;

wire [1:0]   signed_sel ;

assign signed_sel = sign_sel ? 2'b01 : 2'b00;  // 符号位控制

// 需要写入的数据
always@(*)begin
    case(dat_state)
        2'd0:send_data = {1'b0,2'b00,5'd0,OUTPUT_MODE  ,6'd0,signed_sel };
        2'd1:send_data = {1'b0,2'b00,5'd0,DITHER_ENABLE,8'h10           };
        2'd2:send_data = {1'b0,2'b00,5'd0,DCO_OUTPUT   ,8'h1C           };
        2'd3:send_data = {1'b0,2'b00,5'd0,TRANSFER     ,7'd0,1'b1       };
        default:send_data = 24'd0;
    endcase
end

// SPI时序控制器
always@(posedge sys_clk or negedge sys_rst)
begin
    if(!sys_rst)begin
        cs_n <= 1'b1;
        sclk <= 1'b1;
        dat_state <= 2'd0 ;
        delay_cnt <= 24'd0;
        spi_state <= 3'd0 ;
    end
    else begin
        case(spi_state)
            3'd0:begin  // 初始化IO口
                cs_n <= 1'b1;
                sclk <= 1'b1;
                dat_state <= 2'd0 ;
                if(delay_cnt >= delay_100ms)begin
                    delay_cnt <= 24'd0;
                    spi_state <= 3'd1 ;
                end
                else begin
                    delay_cnt <= delay_cnt + 1'b1;
                    spi_state <= 3'd0 ;
                end
            end
            3'd1:begin
                cs_n <= 1'b1;
                sclk <= 1'b1;
                spi_state <= 3'd2 ;
            end
            3'd2:begin
                cs_n  <= 1'b0;
                spi_state <= 3'd3 ;
            end
            3'd3:begin
                if(delay_cnt >= slck_counter)begin
                    delay_cnt <= 24'd0;
                    sclk <= ~sclk;
                    spi_state <= 3'd4 ;
                end
                else begin
                    delay_cnt <= delay_cnt + 1'b1;
                    sclk <= ~sclk;
                    spi_state <= 3'd3 ;
                end
            end
            3'd4:begin
                sclk <= 1'b1;
                spi_state <= 3'd5 ;
            end
            3'd5:begin
                cs_n <= 1'b1;
                if(dat_state >= 2'd3)begin
                    dat_state <= 2'd3;
                    spi_state <= 3'd5;
                end
                else begin
                    dat_state <= dat_state + 1'b1;
                    spi_state <= 3'd1;
                end
            end
            default:spi_state <= 3'd0;
        endcase
    end
end

always@(posedge sys_clk or negedge sys_rst)
begin
    if(!sys_rst)begin
        cs_reg   <= 1'b0;
        sclk_reg <= 1'b0;
    end
    else begin
        cs_reg   <= cs_n;
        sclk_reg <= sclk;
    end
end

assign cs_nege   = ( ~cs_n ) & cs_reg   ;
assign sclk_nege = ( ~sclk ) & sclk_reg ;

// 对数据进行移位处理
always@(posedge sys_clk or negedge sys_rst)
begin
    if(!sys_rst)begin
        mosi <= 1'b0;
        spi_data <= 16'd0;
    end
    else if(cs_nege == 1'b1)begin
        mosi <= 1'b0;
        spi_data <= send_data;
    end
    else if(sclk_nege == 1'b1)begin
        mosi <= spi_data[23];
        spi_data <= {spi_data[22:0],1'b0};
    end
    else begin
        mosi <= mosi;
        spi_data <= spi_data;
    end
end

assign spi_cs_n = cs_reg ;
assign spi_sclk = sclk_reg ;
assign spi_mosi = mosi ;

endmodule
