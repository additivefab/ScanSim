module AD9268_TOP(
    input   wire          SYS_CLK   ,  // 系统时钟输入
    input   wire          SYS_RST   ,  // 系统复位输入
    input   wire          DCO_A     ,  // 通道A DCO时钟
    input   wire          DCO_B     ,  // 通道B DCO时钟
    input   wire  [15:0]  AD_IN_A   ,  // ADC输入通道A
    input   wire  [15:0]  AD_IN_B   ,  // ADC输入通道B
    input   wire          OTR_A     ,  // 通道A溢出标志位
    input   wire          OTR_B     ,  // 通道B溢出标志位
    output  wire          ADC_CLK   ,  // ADC时钟
    output  wire          SPI_CS_N  ,  // SPI片选
    output  wire          SPI_SCLK  ,  // SPI时钟线
    output  wire          SPI_MOSI  ,  // SPI数据线
    output  wire          PDWN      ,  // 数据位置使能，必须置0
    output  wire          OEB       ,  // 时钟线使能  ，必须置0
    output  wire  [15:0]  AD_OUT_A  ,  // 通道A输出数据
    output  wire  [15:0]  AD_OUT_B     // 通道B输出数据
);

wire CLK_125M;

reg  [15:0] ADC_DATA_A;
reg  [15:0] ADC_DATA_B;

// 锁相环模块
PLL u_PLL(
    .areset ( !SYS_RST ),
    .inclk0 ( SYS_CLK  ),
    .c0     ( CLK_125M ) 
);

// SPI模块
ad9268_spi u_ad9268_spi(
    .sys_clk  ( SYS_CLK  ),
    .sys_rst  ( SYS_RST  ),
    .sign_sel ( 1'b0     ), // 设置数据的符号位 1:有符号 0:无符号
    .spi_cs_n ( SPI_CS_N ),
    .spi_sclk ( SPI_SCLK ),
    .spi_mosi ( SPI_MOSI )
);

always@(posedge DCO_A or negedge SYS_RST)
begin
    if(!SYS_RST)begin
        ADC_DATA_A <= 16'd0;
    end
    else begin
        ADC_DATA_A <= AD_IN_A;
    end
end

always@(posedge DCO_B or negedge SYS_RST)
begin
    if(!SYS_RST)begin
        ADC_DATA_B <= 16'd0;
    end
    else begin
        ADC_DATA_B <= AD_IN_B;
    end
end

assign  PDWN = 1'b0;
assign  OEB  = 1'b0;

assign  ADC_CLK  = CLK_125M   ;
assign  AD_OUT_A = ADC_DATA_A ;
assign  AD_OUT_B = ADC_DATA_B ;

endmodule
