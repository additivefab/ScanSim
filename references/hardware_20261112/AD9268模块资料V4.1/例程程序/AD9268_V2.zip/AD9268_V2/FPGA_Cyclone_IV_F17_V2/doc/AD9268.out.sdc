## Generated SDC file "E:/FPGA/AD9268/Winnerl_ARM+FPGA_XIAOCHI/doc/AD9268.out.sdc"

## Copyright (C) 1991-2013 Altera Corporation
## Your use of Altera Corporation's design tools, logic functions 
## and other software and tools, and its AMPP partner logic 
## functions, and any output files from any of the foregoing 
## (including device programming or simulation files), and any 
## associated documentation or information are expressly subject 
## to the terms and conditions of the Altera Program License 
## Subscription Agreement, Altera MegaCore Function License 
## Agreement, or other applicable license agreement, including, 
## without limitation, that your use is for the sole purpose of 
## programming logic devices manufactured by Altera and sold by 
## Altera or its authorized distributors.  Please refer to the 
## applicable agreement for further details.


## VENDOR  "Altera"
## PROGRAM "Quartus II"
## VERSION "Version 13.0.0 Build 156 04/24/2013 SJ Full Version"

## DATE    "Mon Sep 09 16:53:14 2024"

##
## DEVICE  "EP4CE10F17C8"
##


#**************************************************************
# Time Information
#**************************************************************

set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************

create_clock -name {CLK_50M} -period 20.000 -waveform { 0.000 10.000 } [get_ports {SYS_CLK}]
create_clock -name {CLK_125M} -period 8.000 -waveform { 0.000 4.000 } [get_ports {ADC_CLK DCO_A DCO_B}]


#**************************************************************
# Create Generated Clock
#**************************************************************

create_generated_clock -name {u_PLL|altpll_component|auto_generated|pll1|clk[0]} -source [get_pins {u_PLL|altpll_component|auto_generated|pll1|inclk[0]}] -duty_cycle 50.000 -multiply_by 5 -divide_by 2 -master_clock {CLK_50M} [get_pins {u_PLL|altpll_component|auto_generated|pll1|clk[0]}] 


#**************************************************************
# Set Clock Latency
#**************************************************************



#**************************************************************
# Set Clock Uncertainty
#**************************************************************

set_clock_uncertainty -rise_from [get_clocks {CLK_125M}] -rise_to [get_clocks {CLK_50M}]  0.030  
set_clock_uncertainty -rise_from [get_clocks {CLK_125M}] -fall_to [get_clocks {CLK_50M}]  0.030  
set_clock_uncertainty -fall_from [get_clocks {CLK_125M}] -rise_to [get_clocks {CLK_50M}]  0.030  
set_clock_uncertainty -fall_from [get_clocks {CLK_125M}] -fall_to [get_clocks {CLK_50M}]  0.030  
set_clock_uncertainty -rise_from [get_clocks {CLK_50M}] -rise_to [get_clocks {CLK_50M}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {CLK_50M}] -fall_to [get_clocks {CLK_50M}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {CLK_50M}] -rise_to [get_clocks {CLK_50M}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {CLK_50M}] -fall_to [get_clocks {CLK_50M}]  0.020  


#**************************************************************
# Set Input Delay
#**************************************************************



#**************************************************************
# Set Output Delay
#**************************************************************



#**************************************************************
# Set Clock Groups
#**************************************************************



#**************************************************************
# Set False Path
#**************************************************************



#**************************************************************
# Set Multicycle Path
#**************************************************************



#**************************************************************
# Set Maximum Delay
#**************************************************************



#**************************************************************
# Set Minimum Delay
#**************************************************************



#**************************************************************
# Set Input Transition
#**************************************************************

