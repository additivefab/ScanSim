ScanSim research snapshot 0.1.0.dev0
Source commit: 631c542657255f04b7c5effe0d6310598469fde4
Target: macOS CPython 3.14 x86_64 process.
Verified scope: same-host isolated installation; software fixtures; no hardware acceptance.

From this extracted directory:
python3 -m venv offline_env
offline_env/bin/python -m pip install --no-index --find-links wheelhouse --require-hashes -r requirements.lock
offline_env/bin/python -m pip check
offline_env/bin/zlscan --version

Generate and re-read synthetic examples (choose new output directories):
offline_env/bin/python -I audits/audit_dynamic_identification.py --out example_dynamic
offline_env/bin/python -I audits/audit_dynamic_identification.py --out example_dynamic --verify
offline_env/bin/python -I audits/audit_timing_identification.py --out example_timing
offline_env/bin/python -I audits/audit_timing_identification.py --out example_timing --verify

Build backend wheels and build.lock are included for the matching source checkout.
CPython, ensurepip/pip, OS, dev tests and external simulators are outside these hash locks.
All original wheel metadata and bundled license files are retained unchanged.
