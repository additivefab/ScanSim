from pathlib import Path
from email.parser import Parser
from zipfile import ZipFile
import hashlib, json, os, shutil, subprocess, sys, tempfile
repo=Path.cwd(); base=repo/'evidence_runs/2026-11-13_segmented_rows/output'
build=base/'wheel-02'; old=repo/'evidence_runs/2026-11-13_component_views/output/wheel'
oldwork=Path((old/'work_dir.txt').read_text().strip()); buildwork=Path((build/'work_dir.txt').read_text().strip())
out=base/'wheel-offline'; out.mkdir()
work=Path(tempfile.mkdtemp(prefix='segmented-offline-',dir=Path.home()/'.cache/zlscan-wheel-audit'))
(out/'work_dir.txt').write_text(str(work)+'\n')
house=work/'wheelhouse'; house.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((old/'wheelhouse_manifest.json').read_text())
for name,item in prior.items():
 if name=='zlscan': continue
 p=oldwork/'wheelhouse'/item['filename']; assert sha(p)==item['sha256'];shutil.copyfile(p,house/p.name)
wheel=next((buildwork/'dist').glob('*.whl'));shutil.copyfile(wheel,house/wheel.name)
expected=json.loads((build/'expected.json').read_text())
with ZipFile(wheel) as z:
 for rel,digest in expected['assets'].items(): assert hashlib.sha256(z.read(rel)).hexdigest()==digest
manifest=json.loads((build/'source_manifest.json').read_text())
# Verify the built snapshot against the committed source blobs, including developer evidence.
for rel,digest in manifest.items():
 assert sha(buildwork/'source-snapshot'/rel)==digest
 blob=subprocess.check_output(['git','show','3f42972:'+rel]); assert hashlib.sha256(blob).hexdigest()==digest
locked={}
for candidate in sorted(house.glob('*.whl')):
 with ZipFile(candidate) as z:
  m=Parser().parsestr(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode())
 name=m['Name'].lower().replace('_','-');locked[name]=dict(version=m['Version'],filename=candidate.name,sha256=sha(candidate))
assert len(locked)==20
lock=out/'requirements.lock';lock.write_text('\n'.join(f"{name}{'[ident]' if name=='zlscan' else ''}=={v['version']} --hash=sha256:{v['sha256']}" for name,v in sorted(locked.items()))+'\n')
(out/'wheelhouse_manifest.json').write_text(json.dumps(locked,indent=2)+'\n')
commands=[];env=dict(os.environ)
for key in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV'):env.pop(key,None)
def run(label,argv):
 p=subprocess.run(argv,cwd=work,env=env,capture_output=True,text=True)
 (out/(label+'.log')).write_text(p.stdout+p.stderr);commands.append(dict(label=label,argv=argv,returncode=p.returncode))
 (out/'commands.json').write_text(json.dumps(commands,indent=2));assert p.returncode==0,p.stderr
run('venv',[sys.executable,'-m','venv',str(work/'runtime')]);python=work/'runtime/bin/python'
run('install',[str(python),'-m','pip','install','--quiet','--no-index','--find-links',str(house),'--require-hashes','-r',str(lock)])
run('pip-check',[str(python),'-m','pip','check'])
shutil.copyfile(repo/'tools/wheel_smoke.py',work/'wheel_smoke.py')
run('smoke',[str(python),'-I',str(work/'wheel_smoke.py'),'--out',str(work/'smoke'),'--expected',str(build/'expected.json'),'--prefix',str(work/'runtime'),'--forbidden-source',str(repo/'src')])
shutil.copyfile(repo/'tools/audit_static_identification.py',work/'static_audit.py')
run('static',[str(python),'-I',str(work/'static_audit.py'),'--out',str(work/'static')])
run('static-verify',[str(python),'-I',str(work/'static_audit.py'),'--verify',str(work/'static')])
(out/'audit.json').write_text(json.dumps(dict(source_commit='3f42972bc6c7e31927f3071e4e2da424682113a9',all_snapshot_blobs_verified=True,assets=len(expected['assets']),locked_distributions=len(locked),wheel_sha256=sha(wheel),cached_dependencies_verified=True,network_index_resolution='failed; cached locked dependencies used',scope='same host offline install'),indent=2)+'\n')
print('current built wheel + verified cached dependencies offline install passed')
