from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import sys
from zlscan.evidence.records import compare, environment_info, git_state, write_record
from zlscan.io.manifest import sha256_file
repo = Path.cwd()
base = repo/'evidence_runs/2026-11-13_segmented_rows'
started = datetime.now(timezone.utc)
code = git_state(repo)
assert code['dirty'] is False
output = base/'output/formal-02'
commands, logs = [], []
for extra in ([], ['--verify']):
    argv = [sys.executable, 'tools/audit_segmented_rows.py', '--out', str(output), *extra]
    result = subprocess.run(argv, capture_output=True, text=True)
    commands.append(dict(argv=argv, returncode=result.returncode))
    logs.append(result.stdout+result.stderr)
    (base/'output/formal_progress.json').write_text(json.dumps(commands,indent=2))
    assert result.returncode == 0, logs[-1]
audit = json.loads((output/'audit.json').read_text())
criteria = [compare('HTTP responses and exact fresh-process bytes',28,audit['http_responses']),
            compare('density error below explicit synthetic .002 OD criterion',True,audit['max_density_error_od']<.002),
            compare('source epochs equal [0,1]',True,audit['source_epochs']==[0,1]),
            compare('original gap positions',2,audit['gap_positions']),
            compare('unplaced orphan block',1,audit['unplaced_blocks'])]
inputs={str(p.relative_to(repo)):sha256_file(p) for p in [repo/'tools/audit_segmented_rows.py',output/'source_manifest.json',output/'common_calibration.json']}
path=write_record(base/'record/formal', name='observable segmented row software pipeline',status='independent_rerun',conclusion='pass', commands=commands,inputs=inputs,seed=None,criteria=criteria,started_at=started,finished_at=datetime.now(timezone.utc),log_text='\n'.join(logs),code=code,environment=environment_info(),notes='SIMULATED analytic static fixture. Both epochs have actual fitted observable references with exactly equal items. Inner orphan/narrow-epoch CLI exit 1 is expected and checked. No browser or measured hardware acceptance.')
print(path)
