from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,shutil,subprocess,tarfile
from zlscan.evidence.records import compare,write_record
repo=Path.cwd();base=repo/'evidence_runs/2026-11-13_segmented_rows';out=base/'output'
work=Path((out/'wheel-offline/work_dir.txt').read_text().strip())
buildwork=Path((out/'wheel-02/work_dir.txt').read_text().strip())
for name in ('smoke','static'):
 shutil.copytree(work/name,out/'wheel-offline/runtime_cases'/name)
wheel=next((buildwork/'dist').glob('*.whl'));folder=out/'wheel-offline/wheel';folder.mkdir();shutil.copyfile(wheel,folder/wheel.name)
probe="import json,zlscan;from zlscan.evidence.records import environment_info;from pathlib import Path;import sys;assert Path(zlscan.__file__).resolve().is_relative_to(Path(sys.prefix).resolve());assert sys.flags.isolated;print(json.dumps(dict(environment=environment_info(),module=zlscan.__file__,prefix=sys.prefix)))"
argv=[str(work/'runtime/bin/python'),'-I','-c',probe];env=dict(os.environ)
for k in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV'):env.pop(k,None)
p=subprocess.run(argv,cwd=work,env=env,capture_output=True,text=True);assert p.returncode==0,p.stderr
(out/'installed_environment.json').write_text(p.stdout)
installed=json.loads(p.stdout);audit=json.loads((out/'installed/audit.json').read_text());array=json.loads((out/'installed_comparison.json').read_text())
commands=json.loads((out/'installed_commands.json').read_text())+[dict(argv=argv,returncode=p.returncode)]
inputs={str(x.relative_to(repo)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (out/'installed/source_manifest.json',out/'wheel-offline/requirements.lock',out/'installed_comparison.json',folder/wheel.name)}
log=out/'installed_outer.log';stamp=log.stat()
write_record(base/'record/installed',name='isolated installed segmented source provenance',status='independent_rerun',conclusion='pass',commands=commands,inputs=inputs,seed=None,criteria=[compare('HTTP responses and fresh-process exact bytes',28,audit['http_responses']),compare('developer and installed arrays equal including NaN',12,len(array['equal_arrays'])),compare('synthetic density error below .002 OD',True,audit['max_density_error_od']<.002)],started_at=datetime.fromtimestamp(stamp.st_birthtime,timezone.utc),finished_at=datetime.now(timezone.utc),log_text=log.read_text(),code=dict(commit='3f42972bc6c7e31927f3071e4e2da424682113a9',dirty=False,basis='built source snapshot checked against every committed git blob'),environment=installed['environment'],notes='Both build/download network failures retained. Current wheel built during second attempt; 19 previous cached dependencies SHA256 verified, total 20 distributions installed offline with --require-hashes. Installed prefix checked with -I. Same host only; no full pytest repeated in installed environment, browser or hardware acceptance.')
art=base/'record/artifacts';art.mkdir()
files=sorted(x for x in out.rglob('*') if x.is_file())
manifest={str(x.relative_to(out)):hashlib.sha256(x.read_bytes()).hexdigest() for x in files}
archive=art/'output.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for x in files:tar.add(x,arcname=str(x.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=[m for m in tar.getmembers() if m.isfile()];assert len(members)==len(manifest)
 for m in members:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==manifest[m.name]
(art/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(art/'archive_check.json').write_text(json.dumps(dict(files=len(files),every_member_sha256_matches_original=True,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_size_bytes=archive.stat().st_size),indent=2)+'\n')
print('records and exact original archive verified',len(files))
