from pathlib import Path
import os, json, subprocess
import numpy as np
repo=Path.cwd()
base=repo/'evidence_runs/2026-11-13_segmented_rows'
work=Path((base/'output/wheel-offline/work_dir.txt').read_text().strip())
python=work/'runtime/bin/python'
env=dict(os.environ)
for key in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV'): env.pop(key,None)
commands=[]
for extra in ([], ['--verify']):
 argv=[str(python),'-I',str(repo/'tools/audit_segmented_rows.py'),'--out',str(base/'output/installed'),*extra]
 p=subprocess.run(argv,cwd=work,env=env,capture_output=True,text=True)
 commands.append(dict(argv=argv,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
 (base/'output/installed_commands.json').write_text(json.dumps(commands,indent=2))
 assert p.returncode==0,p.stderr
arrays=[]
for case in ('split','gap','orphan'):
 with np.load(base/f'output/formal-02/{case}/density.npz') as a, np.load(base/f'output/installed/{case}/density.npz') as b:
  assert a.files==b.files
  for name in a.files:
   np.testing.assert_equal(a[name],b[name])
   arrays.append(f'{case}/{name}')
(base/'output/installed_comparison.json').write_text(json.dumps(dict(equal_arrays=arrays,equal_nan=True,scope='same-host isolated installed package, not browser/cross-platform/hardware'),indent=2)+'\n')
print('installed CLI + fresh HTTP bytes + developer arrays passed')
