from pathlib import Path
import hashlib,json,tarfile
base=Path('evidence_runs/2026-11-13_dynamic_ident');out=base/'output';art=base/'record/artifacts';art.mkdir()
files=sorted(p for p in out.rglob('*') if p.is_file());manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=art/'output.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for m in members:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==manifest[m.name]
(art/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(art/'archive_check.json').write_text(json.dumps(dict(files=len(files),all_original_member_sha256_verified=True,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2)+'\n')
print('archived exact sources and outputs',len(files))
