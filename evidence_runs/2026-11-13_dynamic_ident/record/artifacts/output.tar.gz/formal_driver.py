from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
from zlscan.evidence.records import compare,environment_info,git_state,write_record
from zlscan.io.manifest import sha256_file
repo=Path.cwd();base=repo/'evidence_runs/2026-11-13_dynamic_ident';started=datetime.now(timezone.utc);code=git_state(repo);assert code['dirty'] is False
root=base/'output/formal';commands=[];logs=[]
for extra in ([],['--verify']):
 argv=[sys.executable,'tools/audit_dynamic_identification.py','--out',str(root),*extra]
 p=subprocess.run(argv,capture_output=True,text=True);commands.append(dict(argv=argv,returncode=p.returncode));logs.append(p.stdout+p.stderr)
 (base/'output/formal_commands.json').write_text(json.dumps(commands,indent=2));assert p.returncode==0,logs[-1]
a=json.loads((root/'audit.json').read_text())
criteria=[compare('independently recomputed CLI cases',4,a['cases']),compare('source file digests unchanged',21,a['source_files_unchanged']),compare('both relative tau errors below .01',True,max(a['relative_errors'].values())<.01),compare('held-out residual below .005 V',True,a['holdout_max_abs_residual_si']<.005),compare('parameter upgrades absent',True,a['parameter_upgrades']==[])]
inputs={str(p.relative_to(repo)):sha256_file(p) for p in [root/'sources.json',repo/'tools/audit_dynamic_identification.py']}
print(write_record(base/'record/formal',name='conditional observed dynamic identification from synthetic scope files',status='independent_rerun',conclusion='pass',commands=commands,inputs=inputs,seed=20261113,criteria=criteria,started_at=started,finished_at=datetime.now(timezone.utc),log_text='\n'.join(logs),code=code,environment=environment_info(),notes='Eight analytic noisy scope files; no real measurements. CLI negative mismatch/flat/reuse cases must exit 1 (outer driver verifies expected codes). Fresh process recomputes full JSON, no parameter evidence upgrades; does not prove interval coverage or hardware response.'))
