import hashlib,json,os,subprocess,zipfile
from pathlib import Path
import xml.etree.ElementTree as E
root=Path(__file__).resolve().parent
out=root/'ci_fixed';out.mkdir(exist_ok=True)
record=root.parent/'record'/'fixed'
record.mkdir(exist_ok=True)
commit='6eeefdbd1c3c5fbd3fd9a98b5136027fdfad884e'
run_id=43384107947
env=dict(os.environ,HTTPS_PROXY='socks5h://127.0.0.1:7897',GH_PROMPT_DISABLED='1')
def get(endpoint):
 return subprocess.run(['gh','api','repos/additivefab/ScanSim/'+endpoint],env=env,check=True,capture_output=True).stdout
def document(endpoint,name):
 raw=get(endpoint);(out/name).write_bytes(raw);return json.loads(raw)
run=document(f'actions/runs/{run_id}','run.json')
jobs=document(f'actions/runs/{run_id}/jobs','jobs.json')['jobs']
artifacts=document(f'actions/runs/{run_id}/artifacts','artifacts.json')['artifacts']
assert run['head_sha']==commit
results=[];members={}
for item in artifacts:
 path=out/f"{item['id']}.zip"
 expected=item['digest'].removeprefix('sha256:')
 if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
  path.write_bytes(get(f"actions/artifacts/{item['id']}/zip"))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
 assert path.stat().st_size==item['size_in_bytes']
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  contents={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
  members[path.name]={n:dict(size=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in contents.items()}
  summary=json.loads(contents['ci-summary.json'])
  assert summary['source_commit']==commit and summary['status']=='passed'
  audit=json.loads(contents['wheel_audit/audit.json'])
  assert audit['source']==dict(commit=commit,dirty=False)
  assert audit['committed_snapshot_verified']
  assert len(audit['commands'])==26 and all(c['returncode']==0 for c in audit['commands'])
  labels={c['label'] for c in audit['commands']}
  assert {'recording_capture','recording_capture_verify'}<=labels
  assert audit['wheel']['python_modules']==154 and len(audit['wheel']['assets'])==5
  assert audit['repeated_build']['byte_identical'] and audit['repeated_build']['independent_source_copy']
  suites=E.fromstring(contents['pytest.xml'])
  counts={k:sum(int(s.attrib[k]) for s in suites.findall('testsuite')) for k in ['tests','failures','errors','skipped']}
  assert counts['failures']==counts['errors']==0
  cases=[t for t in suites.iter('testcase') if t.attrib.get('classname')=='tests.unit.test_recording_capture']
  assert len(cases)==6 and all(t.find('skipped') is None for t in cases)
  capture_audit=json.loads(contents['wheel_audit/recording_capture.json'])
  assert capture_audit['exported_epochs']==[0,1,2]
  assert capture_audit['logical_reset_preserves_settings'] and capture_audit['continuous_resume_branch_identical']
  assert capture_audit['actual_measurements_obtained'] is False
  captures=[]
  for name in ['baseline','resumed','branch']:
   prefix=f'installed_examples/recording_capture/{name}/'
   capture_bytes=contents[prefix+'capture.json'];capture=json.loads(capture_bytes)
   raw_sha=hashlib.sha256(contents[prefix+'raw.zlraw']).hexdigest()
   assert capture['raw_sha256']==raw_sha and capture['version']==2
   assert capture_audit['raw_sha256']==raw_sha
   receipt=json.loads(contents[prefix+'run.json'])
   assert receipt['status']=='complete'
   assert receipt['capture_sha256']==hashlib.sha256(capture_bytes).hexdigest()
   captures.append(capture_bytes)
  assert captures[0]==captures[1]==captures[2]
  geometry_tests=[t for t in suites.iter('testcase') if t.attrib.get('classname')=='tests.unit.test_geometry_identification']
  assert len(geometry_tests)==19 and all(t.find('skipped') is None for t in geometry_tests)
  assert {'test_missing_window_length_is_controlled_rejection','test_same_row_new_epoch_cannot_borrow_phase','test_validation_grid_cannot_validate_identified_feed_offset','test_slanted_only_identifies_offset_combination','test_covariance_matches_independent_normal_matrix','test_validation_mismatch_does_not_refit','test_cli_writes_report_and_does_not_overwrite'} <= {t.attrib['name'] for t in geometry_tests}
  assert {'geometry_identification','geometry_identification_verify'}<=labels
  geometry=json.loads(contents['wheel_audit/geometry_identification.json'])
  assert geometry['cases']==4 and geometry['maximum_error_standard_uncertainties']<4
  assert geometry['actual_measurements_obtained'] is False and geometry['parameter_upgrades']==[]
  reports={}
  for name,status,validation in [('identified','identified','compatible'),('grid_only','partially_identifiable','compatible'),('mismatch','identified','mismatch'),('no_anchor','unidentifiable','unidentifiable')]:
   prefix='installed_examples/geometry_identification/'+name+'/'
   r=json.loads(contents[prefix+'run.json']);reports[name]=r
   assert r['status']==status and r['validation']['status']==validation
   assert not r['hard_acceptance_eligible'] and not r['parameter_upgrades']
   assert r['origin']=='MODEL_ESTIMATE'
   assert len(contents[prefix+'geometry_residuals.svg'])>1000
   assert len(contents[prefix+'geometry_residuals.png'])>1000
   for f in r['facets'].values():
    if name=='identified':assert f['rank']==4
    if name=='grid_only':assert f['rank']==3 and f['parameters']['y_offset_m']['value'] is None
    if name=='no_anchor':assert all(p['value'] is None for p in f['parameters'].values())
  for phase,f in reports['identified']['facets'].items():
   assert {k:v for k,v in f.items() if k!='rows'}=={k:v for k,v in reports['mismatch']['facets'][phase].items() if k!='rows'}
  results.append(dict(artifact=item,tests=counts,passed=counts['tests']-counts['skipped'],source_commit=commit,commands=len(audit['commands']),recording_capture=capture_audit,geometry=geometry,zip_verified=True,executed_recording_capture_tests=6,executed_geometry_tests=19))
print(json.dumps(dict(run_status=run['status'],conclusion=run['conclusion'],jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion']) for j in jobs],verified_artifacts=len(results)),indent=2))
if run['status']!='completed':
 print('Verified live run; final acceptance not yet issued')
 raise SystemExit(0)
assert run['conclusion']=='success' and len(jobs)==6 and all(j['conclusion']=='success' for j in jobs)
assert len(results)==6
(record/'ci_members.json').write_text(json.dumps(members,indent=2)+'\n')
(record/'ci_acceptance.json').write_text(json.dumps(dict(source_commit=commit,run_id=run_id,results=results,scope='actual configured six-target software CI; not browser or hardware acceptance'),indent=2)+'\n')
print('All six targets and original artifact contents verified')
