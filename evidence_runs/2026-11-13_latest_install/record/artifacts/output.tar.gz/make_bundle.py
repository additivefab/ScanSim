from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,tarfile,tempfile
from zlscan.evidence.records import compare,environment_info,write_record
from zlscan.io.manifest import sha256_file
repo=Path.cwd();base=repo/'evidence_runs/2026-11-13_latest_install';out=base/'output';formal=out/'formal'
audit=json.loads((formal/'audit.json').read_text());assert not audit['source']['dirty'] and audit['committed_snapshot_verified']
code=audit['source'];started=datetime.now(timezone.utc);work=Path(audit['work_dir']);tag=f"scansim-macos-x86_64-cpython314-{code['commit'][:7]}"
cache=Path(tempfile.mkdtemp(prefix='bundle-',dir=Path.home()/'.cache/zlscan-wheel-audit'));payload=cache/'payload'/tag;payload.mkdir(parents=True)
for label,house,manifest in [('wheelhouse',work/'wheelhouse',json.loads((formal/'wheelhouse_manifest.json').read_text())),('build_wheelhouse',out/'build_wheels',json.loads((out/'build_manifest.json').read_text()))]:
 folder=payload/label;folder.mkdir()
 for item in manifest.values():
  p=house/item['filename'];assert sha256_file(p)==item['sha256'];shutil.copyfile(p,folder/p.name)
for src,dest in [(formal/'requirements.lock','requirements.lock'),(formal/'build.lock','build.lock'),(formal/'wheelhouse_manifest.json','wheelhouse_manifest.json'),(out/'build_manifest.json','build_manifest.json'),(formal/'expected.json','expected_sources.json')]:shutil.copyfile(src,payload/dest)
(payload/'audits').mkdir()
for name in ('wheel_smoke.py','audit_static_identification.py','audit_dynamic_identification.py','audit_timing_identification.py','audit_segmented_rows.py'):
 shutil.copyfile(work/'source-snapshot/tools'/name,payload/'audits'/name)
(payload/'README.txt').write_text(f'''ScanSim research snapshot 0.1.0.dev0
Source commit: {code['commit']}
Target: macOS CPython 3.14 x86_64 process.
Verified scope: same-host isolated installation; software fixtures; no hardware acceptance.

From this extracted directory:
python3 -m venv offline_env
offline_env/bin/python -m pip install --no-index --find-links wheelhouse --require-hashes -r requirements.lock
offline_env/bin/python -m pip check
offline_env/bin/zlscan --version

Generate and re-read synthetic examples (choose new output directories):
offline_env/bin/python -I audits/audit_dynamic_identification.py --out example_dynamic
offline_env/bin/python -I audits/audit_dynamic_identification.py --out example_dynamic --verify
offline_env/bin/python -I audits/audit_timing_identification.py --out example_timing
offline_env/bin/python -I audits/audit_timing_identification.py --out example_timing --verify

Build backend wheels and build.lock are included for the matching source checkout.
CPython, ensurepip/pip, OS, dev tests and external simulators are outside these hash locks.
All original wheel metadata and bundled license files are retained unchanged.
''')
checks={str(p.relative_to(payload)):sha256_file(p) for p in sorted(payload.rglob('*')) if p.is_file()}
(payload/'CHECKSUMS.json').write_text(json.dumps(checks,indent=2)+'\n')
folder=repo/'install/bundles';folder.mkdir(exist_ok=True);archive=folder/(tag+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(payload.rglob('*')):
  if p.is_file():tar.add(p,arcname=tag+'/'+str(p.relative_to(payload)),recursive=False)
extracted=cache/'extracted';extracted.mkdir()
with tarfile.open(archive) as tar:tar.extractall(extracted,filter='data')
root=extracted/tag;assert json.loads((root/'CHECKSUMS.json').read_text())==checks
assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == set(checks)|{'CHECKSUMS.json'}
for rel,digest in checks.items():assert sha256_file(root/rel)==digest,rel
wheel_count=sum(1 for p in root.rglob('*.whl'))
commands=[];env=dict(os.environ)
for key in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV'):env.pop(key,None)
env.update(PIP_DISABLE_PIP_VERSION_CHECK='1',PYTHONNOUSERSITE='1')
def run(label,argv):
 p=subprocess.run(argv,cwd=root,env=env,capture_output=True,text=True)
 (out/(label+'.log')).write_text(p.stdout+p.stderr);commands.append(dict(label=label,argv=argv,returncode=p.returncode))
 (out/'bundle_commands.json').write_text(json.dumps(commands,indent=2));assert p.returncode==0,p.stderr
run('bundle_venv',[sys.executable,'-m','venv',str(cache/'runtime')]);python=cache/'runtime/bin/python'
run('bundle_install',[str(python),'-m','pip','install','--quiet','--no-index','--find-links',str(root/'wheelhouse'),'--require-hashes','-r',str(root/'requirements.lock')])
run('bundle_check',[str(python),'-m','pip','check'])
probe="""import hashlib,json,sys,zlscan
from pathlib import Path
from importlib.resources import files
import zlscan.ident.dynamic,zlscan.ident.timing
assert sys.flags.isolated
assert Path(zlscan.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())
expected=json.loads(Path('expected_sources.json').read_text())
assert zlscan.__version__==expected['version']
for group in ('assets','python_sources'):
 for name,digest in expected[group].items():
  assert hashlib.sha256(files('zlscan').joinpath(*Path(name).parts[1:]).read_bytes()).hexdigest()==digest,name
print(json.dumps(dict(prefix=sys.prefix,module=zlscan.__file__,python_modules=len(expected['python_sources']),assets=len(expected['assets']))))
"""
run('bundle_provenance',[str(python),'-I','-c',probe])
run('bundle_version',[str(cache/'runtime/bin/zlscan'),'--version'])
parity={}
for feature in ('dynamic','timing'):
 driver=root/'audits'/f'audit_{feature}_identification.py';target=cache/feature
 run('bundle_'+feature,[str(python),'-I',str(driver),'--out',str(target)])
 run('bundle_'+feature+'_verify',[str(python),'-I',str(driver),'--out',str(target),'--verify'])
 originals=work/(feature+'_identification')
 paths=sorted(p.relative_to(originals) for p in originals.rglob('run.json'))
 for path in paths:assert (originals/path).read_bytes()==(target/path).read_bytes(),str(path)
 parity[feature]=len(paths)
for feature,oldroot in [('dynamic_identification',repo/'evidence_runs/2026-11-13_dynamic_ident/output/formal'),('timing_identification',repo/'evidence_runs/2026-11-13_timing_ident/output/formal-02')]:
 actual=work/feature;paths=sorted(p.relative_to(oldroot) for p in oldroot.rglob('run.json'))
 for p in paths:assert (actual/p).read_bytes()==(oldroot/p).read_bytes(),str(p)
 parity['developer_'+feature]=len(paths)
import numpy as np
arrays=0
for case in ('split','gap','orphan'):
 with np.load(work/f'segmented_rows/{case}/density.npz') as a,np.load(repo/f'evidence_runs/2026-11-13_segmented_rows/output/formal-02/{case}/density.npz') as b:
  assert a.files==b.files
  for name in a.files:np.testing.assert_equal(a[name],b[name]);arrays+=1
result=dict(source=code,bundle=str(archive.relative_to(repo)),sha256=sha256_file(archive),size_bytes=archive.stat().st_size,members_verified=len(checks)+1,locked_wheels=wheel_count,parity=parity,segmented_arrays_equal_including_nan=arrays,work_dir=str(cache),scope='same host unpacked bundle fresh venv; other machine/OS not executed')
(out/'bundle_audit.json').write_text(json.dumps(result,indent=2)+'\n')
write_record(base/'record/bundle',name='unpacked portable offline bundle fresh installation and CLI parity',status='independent_rerun',conclusion='pass',commands=commands,inputs={str(archive.relative_to(repo)):result['sha256'],str(formal/'requirements.lock'):sha256_file(formal/'requirements.lock')},seed=20261113,criteria=[compare('wheel artifacts in bundle',23,wheel_count),compare('new dynamic result parity',4,parity['dynamic']),compare('new timing result parity',6,parity['timing']),compare('segmented arrays equal including NaN',12,arrays)],started_at=started,finished_at=datetime.now(timezone.utc),log_text=json.dumps(result,indent=2),code=code,environment=dict(host=environment_info(),runtime=json.loads((out/'bundle_provenance.log').read_text())),notes='Fresh venv from actual unpacked delivered archive; -I module paths and all 150 Python/5 resource bytes checked. Independent dynamic/timing CLI cases exactly match formal installed and developer bytes. Same host only, not browser/other OS/real hardware.')
print(json.dumps(result))
