from pathlib import Path
import hashlib,json,shutil,tarfile
base=Path('evidence_runs/2026-11-13_latest_install');out=base/'output';art=base/'record/artifacts';art.mkdir()
# Preserve full generated fixtures/results; environments and frozen Git snapshots are referenced,
# not duplicated. Dependency wheels are in the separately verified delivered bundle.
for label in ('developer-01','formal'):
 audit=json.loads((out/label/'audit.json').read_text());work=Path(audit['work_dir'])
 for name in ('smoke','static_cases','dynamic_identification','timing_identification','segmented_rows'):
  shutil.copytree(work/name,out/'cases'/label/name)
a=json.loads((out/'bundle_audit.json').read_text());work=Path(a['work_dir'])
for name in ('dynamic','timing'):shutil.copytree(work/name,out/'cases/bundle'/name)
expect_a=json.loads((out/'developer-01/expected.json').read_text());expect_b=json.loads((out/'formal/expected.json').read_text())
assert expect_a==expect_b
(out/'runtime_source_parity.json').write_text(json.dumps(dict(all_python_and_resource_source_hashes_equal=True,python_modules=len(expect_b['python_sources']),assets=len(expect_b['assets'])),indent=2)+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file());manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};archive=art/'output.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for m in members:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==manifest[m.name]
(art/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(art/'archive_check.json').write_text(json.dumps(dict(files=len(files),all_original_member_sha256_verified=True,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2)+'\n')
print('archived exact originals',len(files))
