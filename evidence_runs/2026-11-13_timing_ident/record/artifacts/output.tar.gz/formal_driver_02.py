from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
from zlscan.evidence.records import compare,environment_info,git_state,write_record
from zlscan.io.manifest import sha256_file
repo=Path.cwd();base=repo/'evidence_runs/2026-11-13_timing_ident';started=datetime.now(timezone.utc);code=git_state(repo);assert code['dirty'] is False
root=base/'output/formal-02';commands=[];logs=[]
for extra in ([],['--verify']):
 argv=[sys.executable,'tools/audit_timing_identification.py','--out',str(root),*extra];p=subprocess.run(argv,capture_output=True,text=True)
 commands.append(dict(argv=argv,returncode=p.returncode));logs.append(p.stdout+p.stderr)
 (base/'output/formal_commands.json').write_text(json.dumps(commands,indent=2));assert p.returncode==0,logs[-1]
a=json.loads((root/'audit.json').read_text());criteria=[compare('actual CLI cases and independent recomputation',6,a['cli_cases']),compare('source files unchanged',42,a['source_files_unchanged']),compare('facet error below explicit 100 ps criterion',True,a['max_facet_period_error_ps']<100),compare('heldout below explicit 200 ps criterion',True,a['heldout_max_abs_residual_ps']<200),compare('no parameter upgrades',True,a['parameter_upgrades']==[])]
inputs={str(p.relative_to(repo)):sha256_file(p) for p in [root/'sources.json',repo/'tools/audit_timing_identification.py']}
print(write_record(base/'record/formal-02',name='conditional counter-tagged timing software identification',status='independent_rerun',conclusion='pass',commands=commands,inputs=inputs,seed=20261113,criteria=criteria,started_at=started,finished_at=datetime.now(timezone.utc),log_text='\n'.join(logs),code=code,environment=environment_info(),notes='Synthetic large integer timestamps with rounded Gaussian input errors. No actual measurements or interval coverage claim; settings and extraction declarations not physical verification. Negative no-phase/cycle-only/mismatch/reuse CLI exits 1 verified by outer driver. Independent fresh process recomputes all six run JSONs exactly.'))
