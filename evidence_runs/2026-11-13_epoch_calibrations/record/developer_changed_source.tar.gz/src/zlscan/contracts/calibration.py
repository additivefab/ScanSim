"""Header and items of a calibration file (docs/dev/03_contracts.md, section 6).

The file says where it came from (``MODEL`` is derived from the truth and exists only for
regression), which hardware, firmware, register state, gain settings and epochs it is valid for,
and per item its value and uncertainty. An item that cannot be estimated from the given data is
``unidentifiable`` and carries no number.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_serializer, model_validator


class Provenance(StrEnum):
    MODEL = "MODEL"
    SIMULATED = "SIMULATED"
    MEASURED = "MEASURED"


class Binding(BaseModel):
    model_config = ConfigDict(extra="forbid")

    simulation_hash: str | None = None
    hardware_hash: str | None = None
    wiring_rev: str | None = None
    firmware_hash: str | None = None
    register_dump_hash: str | None = None
    channel_roles: dict[str, str | None] = {}
    gain_settings: dict[str, str] = {}
    epoch_range: tuple[int, int] = (0, 0)

    @model_validator(mode="after")
    def _ordered_epochs(self) -> Binding:
        first, last = self.epoch_range
        if not 0 <= first <= last:
            raise ValueError("epoch_range must be ordered and non-negative")
        return self


class EpochBinding(BaseModel):
    model_config = ConfigDict(extra="forbid")

    epoch: int = Field(strict=True, ge=0, le=2**32 - 1)
    binding: Binding

    @model_validator(mode="after")
    def _single_epoch(self) -> EpochBinding:
        if self.binding.epoch_range != (self.epoch, self.epoch):
            raise ValueError("epoch binding must cover exactly its declared epoch")
        return self


class CaptureDescription(BaseModel):
    """Operator-declared capture extent and identity, bound to a specific raw file."""

    model_config = ConfigDict(extra="forbid")

    version: Literal[1, 2] = 1
    raw_sha256: str
    binding: Binding
    lines: int = Field(gt=0)
    epoch_bindings: list[EpochBinding] = []

    @model_validator(mode="after")
    def _epoch_bindings(self) -> CaptureDescription:
        if self.version == 1:
            if self.epoch_bindings:
                raise ValueError("capture version 1 has one common binding")
            return self
        if not self.epoch_bindings:
            raise ValueError("capture version 2 requires explicit epoch bindings")
        epochs = set()
        for entry in self.epoch_bindings:
            if entry.epoch in epochs:
                raise ValueError("duplicate capture epoch binding")
            epochs.add(entry.epoch)
            if not self.binding.epoch_range[0] <= entry.epoch <= self.binding.epoch_range[1]:
                raise ValueError("epoch binding is outside the capture extent")
            for field in (
                "hardware_hash",
                "wiring_rev",
                "firmware_hash",
                "register_dump_hash",
                "channel_roles",
            ):
                if getattr(entry.binding, field) != getattr(self.binding, field):
                    raise ValueError("epoch binding differs from the single-session identity")
        return self

    @model_serializer(mode="wrap")
    def _original_v1_shape(self, handler):
        document = handler(self)
        if self.version == 1:
            document.pop("epoch_bindings", None)
        else:
            document["epoch_bindings"] = sorted(
                document["epoch_bindings"], key=lambda e: e["epoch"]
            )
        return document

    def binding_for_epoch(self, epoch: int) -> Binding:
        if not self.binding.epoch_range[0] <= epoch <= self.binding.epoch_range[1]:
            raise ValueError("epoch is outside the declared capture extent")
        if self.version == 1:
            return self.binding.model_copy(update={"epoch_range": (epoch, epoch)})
        found = [e.binding for e in self.epoch_bindings if e.epoch == epoch]
        if len(found) != 1:
            raise ValueError("observed epoch requires exactly one capture binding")
        return found[0]


class CalibItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: Literal["ok", "unidentifiable"] = "ok"
    value: Any | None = None
    uncertainty: float | None = None
    valid_range: tuple[float, float] | None = None
    method: str | None = None

    @model_validator(mode="after")
    def _unidentifiable_has_no_value(self) -> CalibItem:
        if self.status == "unidentifiable" and self.value is not None:
            raise ValueError("an unidentifiable item must not carry a value")
        return self


class CalibrationHeader(BaseModel):
    model_config = ConfigDict(extra="forbid")

    format_version: int
    provenance: Provenance
    calibration_id: str
    created_at: str
    binds_to: Binding
    valid_conditions: dict[str, Any] = {}
    generator: dict[str, Any] = {}
    items: dict[str, CalibItem] = {}

    def accepted_for_reconstruction(self, allow_model: bool = False) -> bool:
        """A MODEL file is refused unless the caller explicitly allows it (legacy tests only)."""
        return self.provenance is not Provenance.MODEL or allow_model

    def matches_session(
        self,
        *,
        hardware_hash: str | None,
        wiring_rev: str | None,
        firmware_hash: str | None,
        register_dump_hash: str | None,
        gain_settings: dict[str, str],
        epoch: int,
    ) -> bool:
        """True only when every bound field is known and equal to the session's."""
        b = self.binds_to
        pairs = (
            (b.hardware_hash, hardware_hash),
            (b.wiring_rev, wiring_rev),
            (b.firmware_hash, firmware_hash),
            (b.register_dump_hash, register_dump_hash),
        )
        if any(bound is None or bound != actual for bound, actual in pairs):
            return False
        if b.gain_settings != gain_settings:
            return False
        return b.epoch_range[0] <= epoch <= b.epoch_range[1]


_FORMAT_VERSIONS = {1, 2}
_HARDWARE_FIELDS = ("hardware_hash", "wiring_rev", "firmware_hash", "register_dump_hash")


def check_version(calibration: CalibrationHeader) -> None:
    if calibration.format_version not in _FORMAT_VERSIONS:
        raise ValueError(f"unsupported calibration format version {calibration.format_version}")
    item = calibration.items.get("transfer_lut")
    transfers = (
        item.value.get("channels", {}) if item is not None and isinstance(item.value, dict) else {}
    )
    if not isinstance(transfers, dict) or any(
        not isinstance(value, dict) for value in transfers.values()
    ):
        raise ValueError("malformed calibration transfer channels")
    if calibration.format_version == 1:
        if any(
            "normalization" in value or "valid_code_ranges" in value for value in transfers.values()
        ):
            raise ValueError("observed normalization/support requires calibration format version 2")
    elif not transfers or any(
        not isinstance(value.get("normalization"), dict)
        or value["normalization"].get("kind") != "relative_transmittance"
        or not value.get("valid_code_ranges")
        or "excluded_code_ranges" not in value
        for value in transfers.values()
    ):
        raise ValueError(
            "calibration version 2 requires explicit relative normalization and code support"
        )


def require_applicable(
    calibration: CalibrationHeader,
    capture: Binding,
    *,
    allow_model_calibration: bool = False,
) -> None:
    """Reject a calibration that cannot apply to every epoch in the capture."""
    check_version(calibration)
    if not calibration.accepted_for_reconstruction(allow_model_calibration):
        raise ValueError("MODEL calibration is disabled")
    bound = calibration.binds_to
    if bound.simulation_hash is not None or capture.simulation_hash is not None:
        if (
            bound.simulation_hash is None
            or bound.simulation_hash != capture.simulation_hash
            or calibration.provenance is Provenance.MEASURED
        ):
            raise ValueError("incompatible calibration simulation_hash")
    else:
        if calibration.provenance is Provenance.SIMULATED:
            raise ValueError("SIMULATED calibration requires simulation_hash")
        for field in _HARDWARE_FIELDS:
            value = getattr(bound, field)
            if value is None or value != getattr(capture, field):
                raise ValueError(f"incompatible calibration {field}")
    for field in ("gain_settings", "channel_roles"):
        if getattr(bound, field) != getattr(capture, field):
            raise ValueError(f"incompatible calibration {field}")
    first, last = capture.epoch_range
    valid_first, valid_last = bound.epoch_range
    if not valid_first <= first <= last <= valid_last:
        raise ValueError("incompatible calibration epoch_range")


def require_reference_consistency(transfer: dict) -> None:
    """Older files retain compatibility; an explicit failed or malformed assessment is rejected."""
    if "reference_assessment" not in transfer:
        return
    assessment = transfer["reference_assessment"]
    if not isinstance(assessment, dict) or assessment.get("status") not in {
        "compatible",
        "not_assessed",
    }:
        raise ValueError("radiometric reference fit is failed or has an unsupported assessment")


class CalibrationSet(BaseModel):
    """Self-contained, explicit candidate calibrations; selection never uses truth."""

    model_config = ConfigDict(extra="forbid")
    format: Literal["zlscan.calibration-set/1"] = "zlscan.calibration-set/1"
    calibration_set_id: str = Field(min_length=1)
    calibrations: list[CalibrationHeader] = Field(min_length=1)

    @model_validator(mode="after")
    def _unique_ids(self) -> CalibrationSet:
        ids = [cal.calibration_id for cal in self.calibrations]
        if any(not name for name in ids) or len(set(ids)) != len(ids):
            raise ValueError("calibration set IDs must be nonempty and unique")
        for cal in self.calibrations:
            check_version(cal)
        return self


def resolve_calibrations(
    calibration: CalibrationHeader | CalibrationSet,
    capture: CaptureDescription,
    epochs: list[int],
) -> dict[int, CalibrationHeader]:
    """Every observed epoch gets exactly one fully compatible, non-MODEL header."""
    capture = CaptureDescription.model_validate(capture.model_dump(mode="json"))
    if isinstance(calibration, CalibrationSet):
        collection = CalibrationSet.model_validate(calibration.model_dump(mode="json"))
        candidates = collection.calibrations
    else:
        candidates = [CalibrationHeader.model_validate(calibration.model_dump(mode="json"))]
    if any(cal.provenance is Provenance.MODEL for cal in candidates):
        raise ValueError("MODEL calibration is disabled in reconstruction sets")
    result = {}
    for epoch in sorted(set(epochs)):
        binding = capture.binding_for_epoch(epoch)
        matches = []
        for cal in candidates:
            try:
                require_applicable(cal, binding)
            except ValueError:
                continue
            matches.append(cal)
        if len(matches) != 1:
            raise ValueError(
                f"epoch {epoch} requires exactly one applicable calibration; got {len(matches)}"
            )
        result[epoch] = matches[0]
    return result
